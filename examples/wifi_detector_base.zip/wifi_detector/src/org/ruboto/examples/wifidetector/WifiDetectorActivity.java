package org.ruboto.examples.wifidetector;

public class WifiDetectorActivity extends org.ruboto.RubotoActivity {
	public void onCreate(android.os.Bundle arg0) {

               setScriptName("wifi_detector_activity.rb");
               super.onCreate(arg0);
        }

}

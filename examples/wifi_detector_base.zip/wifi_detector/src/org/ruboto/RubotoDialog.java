package org.ruboto;

/***********************************************************
 * 
 * Extends RubotoActivity to specify Theme.Dialog in
 * the AndroidManifest.xml file.
 *
 */

public class RubotoDialog extends RubotoActivity {
}
